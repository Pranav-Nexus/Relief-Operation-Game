#!/usr/bin/env python
# coding: utf-8

# In[1]:


import random
import tkinter as tk
from tkinter import messagebox

# Create the main window
root = tk.Tk()
background_label = tk.Label(root)
background_label.grid(row=0, column=0, columnspan=2, rowspan=16)
root.title("Relief Operation Game")

# Game variables
resources = 100  # Initial resources
people = 50  # Initial number of survivors
day = 0  # Initial day of the relief operation
rescue_teams = 3  # Initial number of rescue teams
supplies = 50  # Initial amount of supplies
injured_people = 0  # Initial number of injured people
morale = 100  # Initial morale level
damage = 0  # Initial damage level
weather = 'Sunny'  # Initial weather conditions
game_duration = 14  # Total duration of the game in days
tries = 3  # Number of tries allowed
days_to_rescue = 7  # Initial number of days remaining to rescue survivors

# Function to update game state
def update_game_state():
    global resources, people, injured_people, morale, damage, weather, day, tries, days_to_rescue
    resources -= 10  # Resources consumed for daily operations
    people -= random.randint(5, 10)  # People lost due to the tsunami
    injured_people += random.randint(0, 5)  # Randomly generate number of injured people
    morale -= 1  # Morale decreases each day
    damage += random.randint(1, 5)  # Randomly increase damage level
    days_to_rescue -= 1  # Reduce days remaining to rescue survivors
    # Update weather conditions
    weather = random.choice(['Sunny', 'Cloudy', 'Rainy', 'Stormy'])
    update_gui()

# Function to print game state
# Function to print game state and update GUI
def update_gui():
    weather_icons = {
        'Sunny': 'Sunny ☀️',
        'Cloudy': 'Cloudy 🌥️',
        'Rainy': 'Rainy 🌧️',
        'Stormy': 'Stormy ⛈️'
    }
    # Clear previous game state
    for widget in root.grid_slaves():
        widget.grid_forget()

    
    # Update game state in GUI
    tk.Label(root, text="Day: " + str(day)).grid(row=0, column=0, sticky="w")
    tk.Label(root, text="Resources: " + str(resources)).grid(row=1, column=0, sticky="w")
    tk.Label(root, text="People: " + str(people)).grid(row=2, column=0, sticky="w")
    tk.Label(root, text="Rescue Teams: " + str(rescue_teams)).grid(row=3, column=0, sticky="w")
    tk.Label(root, text="Supplies: " + str(supplies)).grid(row=4, column=0, sticky="w")
    tk.Label(root, text="Injured People: " + str(injured_people)).grid(row=5, column=0, sticky="w")
    tk.Label(root, text="Morale: " + str(morale)).grid(row=6, column=0, sticky="w")
    tk.Label(root, text="Damage: " + str(damage)).grid(row=7, column=0, sticky="w")
    tk.Label(root, text="Weather: " + weather_icons[weather]).grid(row=8, column=0, sticky="w")
    tk.Label(root, text="Days remaining to rescue survivors: " + str(days_to_rescue)).grid(row=9, column=0, sticky="w")
    tk.Label(root, text="Tries remaining: " + str(tries)).grid(row=10, column=0, sticky="w")

    # Change background image based on weather condition
    if weather == 'Sunny':
        background_image = tk.PhotoImage(file="C:/Users/harih/Documents/College-AIE/Code at Night/sunny.png")
    elif weather == 'Cloudy':
        background_image = tk.PhotoImage(file="C:/Users/harih/Documents/College-AIE/Code at Night/cloudy.png")
    elif weather == 'Rainy':
        background_image = tk.PhotoImage(file="C:/Users/harih/Documents/College-AIE/Code at Night/rainy.png")
    elif weather == 'Stormy':
        background_image = tk.PhotoImage(file="C:/Users/harih/Documents/College-AIE/Code at Night/stormy.png")
    else:
        background_image = tk.PhotoImage(file="C:/Users/harih/Documents/College-AIE/Code at Night/default.png")

    # Update background image in GUI
    background_label.config(image=background_image)
    background_label.image = background_image
    background_label.grid(row=0, column=0, columnspan=2, rowspan=16)

    # Add buttons for game actions
    tk.Button(root, text="Send Rescue Team", command=send_rescue_team).grid(row=11, column=0, sticky="w")
    tk.Button(root, text="Distribute Supplies", command=distribute_supplies).grid(row=12, column=0, sticky="w")
    tk.Button(root, text="Treat Injured", command=treat_injured).grid(row=13, column=0, sticky="w")
    tk.Button(root, text="Repair Damage", command=repair_damage).grid(row=14, column=0, sticky="w")
    tk.Button(root, text="Next Day", command=next_day).grid(row=15, column=0, sticky="w")

    if resources <= 0 or people <= 0 or morale <= 0 or days_to_rescue <= 0 or tries <= 0:
        game_over()


def game_over():
    messagebox.showinfo("Game Over", "The relief operation has failed. You were unable to rescue all the survivors in time.")
    root.destroy()

def send_rescue_team():
    global resources, rescue_teams, days_to_rescue, tries
    if rescue_teams > 0:
        rescued = random.randint(1, 10)
        resources -= rescued * 5 # Resources consumed for sending rescue team
        people += rescued
        days_to_rescue += 1
        rescue_teams -= 1
        tries -= 1
        update_gui()
    else:
        messagebox.showinfo("Error", "No rescue teams available!")

def distribute_supplies():
    global resources, supplies
    if supplies > 0:
        distributed = random.randint(1, 10)
        resources -= distributed * 2 # Resources consumed for distributing supplies
        morale += distributed
        supplies -= distributed
        update_gui()
    else:
        messagebox.showinfo("Error", "No supplies available!")

def treat_injured():
    global resources, injured_people
    if injured_people > 0:
        treated = random.randint(1, 5)
        resources -= treated * 3 # Resources consumed for treating injured
        injured_people -= treated
        update_gui()
    else:
        messagebox.showinfo("Error", "No injured people to treat!")
        
def repair_damage():
    global resources, damage
    if damage > 0:
        repaired = random.randint(1, 5)
        resources -= repaired * 4 # Resources consumed for repairing damage
        damage -= repaired
        update_gui()
    else:
        messagebox.showinfo("Error", "No damage to repair!")


def next_day():
    global day
    update_game_state()
    day += 1
    if day > game_duration:
        game_over()

update_gui()
root.mainloop()

